package com.mycompany.board2;

import java.text.DateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.mycompany.board2.db.BoardDto;
import com.mycompany.board2.service.BoardService;

@Controller
public class BoardController {

	@Inject
	private BoardService boardService;

	private static final Logger logger = LoggerFactory.getLogger(BoardController.class);
	// http://localhost:8080/board2/
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		logger.info("Welcome home! The client locale is {}.", locale);
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		String formattedDate = dateFormat.format(date);
		model.addAttribute("serverTime", formattedDate );
		return "home"; // /WEB-INF/views/home.jsp
	}// home

	// http://localhost:8080/board2/hi
	@RequestMapping("/hi") // value="hi"를 "hi"로 줄이고, method=RequestMethod.GET 은 생략
	public String hi(Model model) {
		model.addAttribute("id", "hong");
		return "hi"; // /WEB-INF/views/hi.jsp
	}// hi

	// http://localhost:8080/board2/writeform
	@RequestMapping("/writeform")
	public String writeform() {
		return "writeform";  // /WEB-INF/views/writeform.jsp
	}// writeform

	@RequestMapping(value="/write", method=RequestMethod.POST)
	public String write(BoardDto dto) {
		// System.out.println("dto=" + dto);
		boardService.insertBoard(dto);
		// return "imsi";
		return "redirect:/list";
	}

	// http://localhost:8080/board2/list
	@RequestMapping("/list")
	public String list0() {
		return "redirect:/list/1"; // http://localhost:8080/board2/list/1
	}//list0

	// http://localhost:8080/board2/list/17
	@RequestMapping("/list/{pg}")
	public String list(@PathVariable(value="pg") int pg, Model model) {
		int count = boardService.countBoard();
		System.out.println("count=" + count);
		int size = 10;
		int begin = (pg-1) * size + 1;
		System.out.println("begin=" + begin);
		int end = begin + (size-1);
		System.out.println("end=" + end);
		HashMap<String, Integer> map = new HashMap<String, Integer>();
		map.put("begin", begin);
		map.put("end", end);
		List<BoardDto> list = boardService.listBoard(map);
		System.out.println("list=" + list);
		int totalPage = (count / size) + (count % size == 0 ? 0 : 1);
		int pageSize = 10;
		int startPage = ((pg-1) / pageSize * pageSize) + 1;
		int endPage = startPage + (pageSize-1);
		if(endPage > totalPage) {
			endPage = totalPage;
		}
		System.out.println("totalPage=" + totalPage);
		int max = count - ((pg-1) * pageSize);
		// 정보들을 model에 담는다.
		model.addAttribute("pg", pg);
		model.addAttribute("list", list);
		model.addAttribute("totalPage", totalPage);
		model.addAttribute("pageSize", pageSize);
		model.addAttribute("startPage", startPage);
		model.addAttribute("endPage", endPage);
		model.addAttribute("max", max);
		return "list"; // WEB-INF/views/list.jsp
	}//list

	@RequestMapping("/read/{num}/{pg}")
	public String read(@PathVariable(value="num") int num,
			@PathVariable(value="pg") int pg, Model model) {
		BoardDto dto = boardService.readBoard(num);
		System.out.println("dto=" + dto);
		model.addAttribute("b", dto);
		model.addAttribute("pg", pg);
		return "read"; // WEB-INF/views/read.jsp
	}//read

	@RequestMapping("/updateform/{num}/{pg}")
	public String updateform(@PathVariable(value="num") int num,
			@PathVariable(value="pg") int pg, Model model) {
		BoardDto dto = boardService.updateformBoard(num);
		System.out.println("updateform, dto=" + dto);
		model.addAttribute("b", dto);
		model.addAttribute("pg", pg);
		return "updateform";
	}//updateform

	@RequestMapping(value="/update", method=RequestMethod.POST)
	public String update(BoardDto dto,
			@RequestParam(value="pg", defaultValue="1") int pg, Model model) {
		int ok = boardService.updateBoard(dto);
		if(ok == 0) {
			return "fail";
		} else {
			return "redirect:/list/" + pg;
		}
	}//update

	@RequestMapping("/deleteform/{num}/{pg}")
	public String deleteform(@PathVariable(value="num") int num,
			@PathVariable(value="pg") int pg, Model model) {
		model.addAttribute("num", num);
		model.addAttribute("pg", pg);
		return "deleteform";
	}//deleteform

	@RequestMapping(value="/delete", method=RequestMethod.POST)
	public String delete(BoardDto dto,
			@RequestParam(value="pg", defaultValue="1") int pg) {
		int ok = boardService.deleteBoard(dto);
		if(ok == 0) {
			return "fail";
		} else {
			return "redirect:/list/" + pg;
		}
	}//delete

}// end





