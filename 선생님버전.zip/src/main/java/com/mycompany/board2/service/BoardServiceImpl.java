package com.mycompany.board2.service;

import java.util.HashMap;
import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import com.mycompany.board2.db.BoardDao;
import com.mycompany.board2.db.BoardDto;

@Service
public class BoardServiceImpl implements BoardService {

	@Inject
	private BoardDao boardDao;

	@Override
	public int insertBoard(BoardDto dto) {
		return boardDao.insertBoard(dto);
	}

	@Override
	public List<BoardDto> listBoard(HashMap<String, Integer> map) {
		return boardDao.listBoard(map);
	}

	@Override
	public BoardDto readBoard(int num) {
		boardDao.updateHit(num); // 조회수 증가
		return boardDao.readBoard(num); // 글 하나 읽기
	}

	@Override
	public int updateBoard(BoardDto dto) {
		return boardDao.updateBoard(dto);
	}

	@Override
	public int deleteBoard(BoardDto dto) {
		return boardDao.deleteBoard(dto);
	}

	@Override
	public int countBoard() {
		return boardDao.countBoard();
	}

	@Override
	public BoardDto updateformBoard(int num) {
		return boardDao.readBoard(num);
	}

}
