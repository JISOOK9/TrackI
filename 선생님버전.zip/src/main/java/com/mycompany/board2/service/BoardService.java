package com.mycompany.board2.service;
import java.util.HashMap;
import java.util.List;

import com.mycompany.board2.db.BoardDto;
public interface BoardService {
	public int insertBoard(BoardDto dto);
	public List<BoardDto> listBoard(HashMap<String, Integer> map);
	public BoardDto readBoard(int num);
	public int updateBoard(BoardDto dto);
	public int deleteBoard(BoardDto dto);
	public int countBoard();
	public BoardDto updateformBoard(int num);
}//end
