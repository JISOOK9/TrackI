package com.mycompany.board2.db;

import java.util.HashMap;
import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

@Repository
public class BoardDaoImpl implements BoardDao {

	@Inject
	private SqlSession sqlSession;

	private static final String namespace ="com.mycompany.board2.mapper.BoardMapper";

	@Override
	public int insertBoard(BoardDto dto) {
		return sqlSession.insert(namespace+".insertBoard", dto);
	}

	@Override
	public List<BoardDto> listBoard(HashMap<String, Integer> map) {
		return sqlSession.selectList(namespace+".listBoard", map);
	}

	@Override
	public BoardDto readBoard(int num) {
		return sqlSession.selectOne(namespace+".readBoard", num);
	}

	@Override
	public int updateBoard(BoardDto dto) {
		return sqlSession.update(namespace+".updateBoard", dto);
	}

	@Override
	public int deleteBoard(BoardDto dto) {
		return sqlSession.delete(namespace+".deleteBoard", dto);
	}

	@Override
	public void updateHit(int num) {
		sqlSession.update(namespace+".updateHit", num);
	}

	@Override
	public int countBoard() {
		return sqlSession.selectOne(namespace+".countBoard");
	}

}//end
