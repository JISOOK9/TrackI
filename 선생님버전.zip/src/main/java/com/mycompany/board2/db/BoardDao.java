package com.mycompany.board2.db;

import java.util.HashMap;
import java.util.List;

public interface BoardDao {
	public int insertBoard(BoardDto dto);
	public List<BoardDto> listBoard(HashMap<String, Integer> map);
	public BoardDto readBoard(int num);
	public int updateBoard(BoardDto dto);
	public int deleteBoard(BoardDto dto);
	public void updateHit(int num);
	public int countBoard();
}//end