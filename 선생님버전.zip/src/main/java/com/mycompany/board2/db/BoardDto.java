package com.mycompany.board2.db;

import java.util.Date;

public class BoardDto {
	private int num;
	private String pwd;
	private String title;
	private String writer;
	private Date regdate;
	private int hit;
	private String content;

	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getWriter() {
		return writer;
	}
	public void setWriter(String writer) {
		this.writer = writer;
	}
	public Date getRegdate() {
		return regdate;
	}
	public void setRegdate(Date regdate) {
		this.regdate = regdate;
	}
	public int getHit() {
		return hit;
	}
	public void setHit(int hit) {
		this.hit = hit;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	@Override
	public String toString() {
		return "BoardDto [num=" + num + ", pwd=" + pwd + ", title=" + title + ", writer=" + writer + ", regdate="
				+ regdate + ", hit=" + hit + ", content=" + content + "]";
	}
}//end